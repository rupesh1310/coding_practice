echo enter your name
read name
echo your name is $name
echo enter your basic salary
read basic
echo vasic salary $basic
if [ $basic -ge 1000000 -a -lt 5000000 ]
then 
echo class one employee
elif [ $basic -ge 1000000 -a 
