while true
do
echo 1.copy file
echo 2.copy directory
echo 3.rename file
echo 4.move file
echo 5.exit
echo enter option
read option
case $option in
1)echo enter source file
read source
echo enter target file
read target
cp $source $target;;
2)echo enter source directory
read sdir
echo enter traget directory
read tdir
cp -r $sdir $tdir;;
3)echo enter the old file name
read old
echo enter the new file name
read new
mv $old $new;;
4) echo enter the old file or directory
read ofile
echo enter the new file or directory
read nfile
mv $ofile $nfile;;
5)exit 0;;
*)entered option is invalid;;
esac
done
 
