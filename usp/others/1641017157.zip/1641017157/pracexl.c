#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>

int main()
{
  pid_t pid;
  pid=fork();
 if(pid==0)
 {
   printf("i am child \n");
  execlp("./as4qs27","as4qs27",NULL);
 }
 else
{
  wait(0);
  printf("i am the parent.the child just ended.\n");
  exit(0);
 }
 return(0);
}
