until false
do
echo hi
read var
if [ $var -eq 0 ]
then 
continue
else
exit
fi 
done 

