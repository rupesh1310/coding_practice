while true
do
echo 1.backup
echo 2.restore
echo 3.compress file
echo 4.decompress file
echo 5.exit
echo enter option
read option
case $option in
1)echo enter source file
read source
echo enter target file
read target
tar $source $target;;
2)echo sorce file to restore
read sdir
echo enter target file to restore
read tdir
restore -i $sdir $tdir;;
3)echo enter the old file to compress
read old
echo enter the new file to compress
read new
mv $old $new;;
4) echo enter the old file or directory
read ofile
echo enter the new file or directory
read nfile
mv $ofile $nfile;;
5)exit 0;;
*)entered option is invalid;;
esac
done

