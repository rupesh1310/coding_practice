while true
do
echo what is your favourite subject
echo M/m MACHINE LEARNING
echo O/o OS
echo D/d DM
echo C/c COA
