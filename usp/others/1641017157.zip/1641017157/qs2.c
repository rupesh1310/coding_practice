#include<stdio.h>
#include<string.h>
int main()
{
  char str[]="*ITER:IBCS;SOA:Pot*Hot:";
  char* token= strtok(str,":;*");
  while(token!=NULL)
 {
     printf("%s\n",token);
    token= strtok(NULL,":;*");
  }
}
  
