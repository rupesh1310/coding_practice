#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/wait.h>
int main()
{
   int pid,pid2;
   pid=fork();
  if(pid)
 {
   pid2=fork();
  printf("iter");
 }
 else
 {
   printf("iter \n");
 pid2=fork();
 }
return 0;
}
