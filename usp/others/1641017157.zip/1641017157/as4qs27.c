#include<stdio.h>
void main()
{
   int a,b,c,d,mul;
  printf("enter the three numbers");
   scanf( "%d %d %d",&a,&b,&c); 
d=a*b;
  mul=d*c;
  printf("%d",mul);
 return;                                                                                                                                                                                                                                                                                     
}
