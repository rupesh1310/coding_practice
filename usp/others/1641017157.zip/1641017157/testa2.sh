echo enter a number
read n
i=$n
while [ $i -ge 1 ]
do
echo $i
i=`expr $i - 1`
done

 
