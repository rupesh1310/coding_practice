#include<stdio.h>
#include<unistd.h>

int main(void){
printf(" my real user id is  %5ld\n",(long)getuid());
printf(" my effective user id is  %5ld\n",(long)getuid());
printf(" my real group id is  %5ld\n",(long)getuid());
printf(" my real user id is  %5ld\n",(long)getuid());
 
return 0; 
}
