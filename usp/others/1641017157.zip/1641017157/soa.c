#include<string.h>
#include<stdio.h>
int main()
{
  char str[]= "SOA , DEEMED,UNIVERSITY";
  char *token=strtok(str,",");
  while(token!= NULL)
 {
   printf("%s\n",token);
  token=strtok(NULL,",");
 }
}
