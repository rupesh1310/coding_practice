#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/wait.h>

int main(void){
 pid_t childpid;
 childpid=fork();
 if(childpid==0) 
 {
   execl("/bin/grep","grep","-n","apple ","meow", NULL);
  perror("child failed to exec ls");
   return 1;
 }
 if(childpid!=wait(NULL))
 {
  perror("parent failed to wait due to signal or error");
 return 1;
}
 return 0;
}
